function main()
    if (Init() == 1) then
        print("Failed to load SDL")
        return
    end
    if (CreateWindow("Game", 1280, 720) == 1) then
        print("Create Window Failed")
        return
    end
    if (CreateRenderer() == 1) then
        print("Create Renderer Failed")
        return
    end
    if (InitImage() == 1) then
        print ("Init PNG failed")
        return
    end

    FPS = 1 / 60
    open = true
    frameTime = 0
	prevTime = 0
	currentTime = 0
	deltaTime = 0

    while open do
        prevTime = currentTime
		currentTime = GetMillis()
		deltaTime = (currentTime - prevTime) / 1000

        PollEvent()
        open = IsAppOpen()
        
        SetColor(100, 100, 100, 255)
        ClearScreen()

        frameTime = frameTime + deltaTime
        while (frameTime >= FPS) do
			frameTime = frameTime - FPS

            -- Call your updates function; called 60 time a second
		end

        -- Rendering here

        Render()
    end
end

main()